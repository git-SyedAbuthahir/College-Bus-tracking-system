# cbts


![login](https://github.com/Thanneermalaichidambaram/CollegebusRadar/assets/113817745/f883137a-6c62-448c-bb1d-ce719cd94151)
![Dashboard](https://github.com/Thanneermalaichidambaram/CollegebusRadar/assets/113817745/551bad8c-140c-4de3-90c1-bbbed048e597)
![scanqr](https://github.com/Thanneermalaichidambaram/CollegebusRadar/assets/113817745/b50464a8-605b-4156-9f8e-ffb37c36a9b7)
![fees](https://github.com/Thanneermalaichidambaram/CollegebusRadar/assets/113817745/cd5213a0-b42f-4862-bc18-9acc1bb50ce0)
![feedback](https://github.com/Thanneermalaichidambaram/CollegebusRadar/assets/113817745/6727a0d4-1b15-42cb-be22-118b2ba8bca2)
